import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        DiaSemana dia = new DiaSemana();

        int numeroDigitado;

        do{
            System.out.println("Informe um numero de 1 a 7: (0 para encerrar) ");
            numeroDigitado = scan.nextInt();

            dia.escolheDia(numeroDigitado);

        }while(numeroDigitado > 0);
    }
}