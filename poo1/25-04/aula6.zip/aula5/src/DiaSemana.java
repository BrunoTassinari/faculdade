public class DiaSemana {

    private int diaSemana;
    public void escolheDia(int numeroDia){
        String diaLocalizado;

        switch (numeroDia){
            case 1:
                diaLocalizado = "Domingo";
                break;
            case 2:
                diaLocalizado = "Segunda";
                break;
            case 3:
                diaLocalizado = "Terça";
                break;
            case 4:
                diaLocalizado = "Quarta";
                break;
            case 5:
                diaLocalizado = "Quinta";
                break;
            case 6:
                diaLocalizado = "Sexta";
                break;
            case 7:
                diaLocalizado = "Sabado";
                break;
            default:
                diaLocalizado = null;
                break;
        }

        if(diaLocalizado != null){
            System.out.println("Hoje é " + diaLocalizado + "!");
        } else {
            System.out.println("Numero inválido!");
        }
    }
}
